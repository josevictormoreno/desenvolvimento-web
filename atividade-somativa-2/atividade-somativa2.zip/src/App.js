import './App.css';
import Rotas from './rotas';

function App() {
    return (
        <div><Rotas /></div>
    );
}

export default App;
